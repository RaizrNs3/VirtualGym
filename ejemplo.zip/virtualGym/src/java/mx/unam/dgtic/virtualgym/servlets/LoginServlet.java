/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mx.unam.dgtic.modelo.dao.UserJDBC;
import mx.unam.dgtic.modelo.dto.User;

/**
 *
 * @author JAVA
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private static String PANTALLA_LOGIN = "/login/login.jsp";
    private static String PANTALLA_CONTROLLER = "/controller";
    private static String PARAMETRO_ACCION = "action";
    private static String PANTALLA_INICIO = "/index.jsp";

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter(PARAMETRO_ACCION);
        if (accion != null) {
            if (accion.equals("salir")) {
                request.getSession(false).invalidate();
                request.getRequestDispatcher(PANTALLA_INICIO).forward(request, response);
            }
        }else if(request.getSession().getAttribute("user") != null){
            request.getRequestDispatcher(PANTALLA_CONTROLLER).forward(request, response);
        }else{
            request.getRequestDispatcher(PANTALLA_LOGIN).forward(request, response);
        }
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Validacion de datos
        HttpSession session;
        String nombre = (String) request.getParameter("user");
        String pass = request.getParameter("password");
        
        User user = null;
        UserJDBC us = new UserJDBC();
        try{
            user = us.selectData(nombre,pass);
        }catch(SQLException err){
            err.printStackTrace();
        }
       
        
        if (user != null) {
            session  = request.getSession();
            session.setAttribute("user", user);
            request.getRequestDispatcher(PANTALLA_CONTROLLER).forward(request, response);
        }else{
            request.getRequestDispatcher(PANTALLA_LOGIN).forward(request, response);
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
