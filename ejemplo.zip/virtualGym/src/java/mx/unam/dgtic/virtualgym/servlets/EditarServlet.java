/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.unam.dgtic.modelo.dto.User;
import mx.unam.dgtic.virtualgym.servicios.EditarService;
import mx.unam.dgtic.virtualgym.servicios.RegistroService;

/**
 *
 * @author Alejandro
 */
public class EditarServlet extends HttpServlet {

    private static final String PANTALLA_LISTA = "/controller?action=lista";
    private static final String PANTALLA_INICIO = "/controller?action=iniciojsp";

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String num = request.getParameter("id");
        int id = Integer.parseInt(num);
        EditarService edserv = new EditarService();
        edserv.cargaInfoUser(id);
        User userInfo = edserv.getDatos();

        request.setAttribute("usuario", userInfo);
        request.getRequestDispatcher("/site/editar.jsp").forward(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        EditarService edit = new EditarService();
        User userUpdate = new User();
        int index = 0;
        List<String> parametros = new ArrayList<>();

        parametros.add(request.getParameter("username"));
        parametros.add(request.getParameter("password"));
        parametros.add(request.getParameter("mail"));
        parametros.add(request.getParameter("gender"));
        parametros.add(request.getParameter("age"));
        parametros.add(request.getParameter("height"));
        parametros.add(request.getParameter("weight"));

        userUpdate.setIdUser(Integer.parseInt(request.getParameter("id")));

        if (parametros.get(0).length() < 60) {
            userUpdate.setUserName(parametros.get(0));
            index++;
        }

        if (parametros.get(1).length() >= 8) {
            userUpdate.setPassword(parametros.get(1));
            index++;
        }

        if (parametros.get(2).contains("@")) {
            userUpdate.setEmail(parametros.get(2));
            index++;
        }

        if (parametros.get(3).equals("M") || parametros.get(3).equals("F")) {
            userUpdate.setSex(parametros.get(3).charAt(0));
            index++;
        }

        if (Integer.parseInt(parametros.get(4)) > 10 && Integer.parseInt(parametros.get(4)) < 80) {
            userUpdate.setAge(Integer.parseInt(parametros.get(4)));
            index++;
        }

        if (Double.parseDouble(parametros.get(5)) > 0) {
            userUpdate.setHeight(Double.parseDouble(parametros.get(5)));
            index++;
        }

        if (Double.parseDouble(parametros.get(6)) > 0) {
            userUpdate.setWeight(Double.parseDouble(parametros.get(6)));
            index++;
        }

        if (index == 7) {
            userUpdate.setImc();
            edit.actualizaUsuario(userUpdate);
            request.getRequestDispatcher(PANTALLA_INICIO).forward(request, response);
        } else {
            request.getRequestDispatcher(PANTALLA_LISTA).forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
