/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servicios;

import java.sql.SQLException;
import mx.unam.dgtic.modelo.dao.UserJDBC;
import mx.unam.dgtic.modelo.dto.User;

/**
 *
 * @author Alejandro
 */
public class RegistroService {
    private UserJDBC userRegistro;
    
    public RegistroService(){
        userRegistro = new UserJDBC();
    }
    
    public boolean registraUsuario(User u){
        int rows = 0;
        try {
            rows = userRegistro.insertData(u);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        if (rows > 0) {
            return true;
        }else{
            return false;
        }
    }
}
