/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servicios;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.unam.dgtic.modelo.dao.UserJDBC;

/**
 *
 * @author Alejandro
 */
public class EliminarService {
    private UserJDBC usuario;
    public EliminarService(){
        usuario = new UserJDBC();
    }
    public void borra(int id){
        try {
            usuario.deleteData(id);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
