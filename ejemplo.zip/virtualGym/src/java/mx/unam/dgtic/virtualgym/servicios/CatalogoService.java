/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servicios;

import java.util.List;
import mx.unam.dgtic.modelo.dao.UrlOpcionDAO;
import mx.unam.dgtic.modelo.dao.UrlOpcionDAOImpl;
import mx.unam.dgtic.modelo.dto.UrlOpcion;


/**
 *
 * @author Alejandro
 */
public class CatalogoService {
    private UrlOpcionDAO urlDAO;
    
    public CatalogoService(){
        urlDAO = new UrlOpcionDAOImpl();
    }
    public List<UrlOpcion> cargaMenu(){
        return urlDAO.cargaOpcionesMenu(UrlOpcionDAO.ESTATUS_ACTIVO);
    }
    
}
