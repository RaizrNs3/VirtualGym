/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.unam.dgtic.modelo.dao.UserJDBC;
import mx.unam.dgtic.modelo.dto.User;
import mx.unam.dgtic.virtualgym.servicios.ListadoService;

/**
 *
 * @author Alejandro
 */
public class ListadoServlet extends HttpServlet {
    
    private static final String PANTALLA_PRINCIPAL = "/site/webapp.jsp?action=lista";

    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ListadoService ls = new ListadoService();
        List<User> usuarios = new ArrayList<>();
        
//        System.out.println("Se llama al servlet de listado");
        ls.cargaUsuarios();
        usuarios = ls.getDatos();
        if (usuarios != null) {
//            for (User usuario2 : usuarios) {
//                System.out.println(usuario2);
//            }
            request.setAttribute("usuarios", usuarios);
            request.getRequestDispatcher(PANTALLA_PRINCIPAL).forward(request, response);
        } else {
            System.out.println("No se puede cargar los datos de los Usuarios");
        }
    }
        @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ListadoService ls = new ListadoService();
        List<User> usuarios = new ArrayList<>();
        
//        System.out.println("Se llama al servlet de listado");
        ls.cargaUsuarios();
        usuarios = ls.getDatos();
        if (usuarios != null) {
//            for (User usuario2 : usuarios) {
//                System.out.println(usuario2);
//            }
            request.setAttribute("usuarios", usuarios);
            request.getRequestDispatcher(PANTALLA_PRINCIPAL).forward(request, response);
        } else {
            System.out.println("No se puede cargar los datos de los Usuarios");
        }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
