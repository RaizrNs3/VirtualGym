/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.unam.dgtic.modelo.dto.UrlOpcion;
import mx.unam.dgtic.virtualgym.servicios.CatalogoService;

/**
 *
 * @author Alejandro
 */
public class CatalogosServlet extends HttpServlet {

    @Override
    public void init(ServletConfig config) throws ServletException{
        super.init(config);
        CatalogoService servicio = new CatalogoService();
        
        List<UrlOpcion> menu = servicio.cargaMenu();
//        for (UrlOpcion op : menu) {
//            System.out.println(op);
//        }
        
        config.getServletContext().setAttribute("menu", menu);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
