/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.filtros;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Alejandro
 */
public class Filtro implements Filter {
    
    private static final boolean debug = true;
    private static final String PANTALLA_INICIO = "/redirect?dir=index";

    // The filter configuration object we are associated with.  If
    // this value is null, this filter instance is not currently
    // configured. 
    private FilterConfig filterConfig = null;
    
    public Filtro() {
    }    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
            try {
            String[] excludes = null;
            if (filterConfig != null) {
                String parameter = filterConfig.getInitParameter("excludes");
                excludes = parameter.split(",");
            }
            HttpServletRequest reqt = (HttpServletRequest) request;
            HttpServletResponse resp = (HttpServletResponse) response;
            HttpSession ses = reqt.getSession(false);
            String reqURI = reqt.getRequestURI();
//            System.out.println("URI==" + reqURI);
            Boolean go = false;
            for (int i = 0; i < excludes.length; i++) {
//                System.out.println("EXCLUDES==" + excludes[i]);
                if (reqURI.indexOf(excludes[i]) >= 0) {
//                    System.out.println("SI APLICA=" + reqURI);
//                    System.out.println("SI APLICA=" + excludes[i]);
                    go = true;
                    break;
                }
            }

            if (go || (ses != null && ses.getAttribute("user") != null)) {
                chain.doFilter(request, response);
            } else {
                resp.sendRedirect(reqt.getContextPath() + PANTALLA_INICIO);
            }
        } catch (IOException | ServletException e) {
            System.out.println(e.getMessage());
        }
    }


    /**
     * Destroy method for this filter
     */
    @Override
    public void destroy() {        
    }

    /**
     * Init method for this filter
     */
    @Override
    public void init(FilterConfig filterConfig) {        
        this.filterConfig = filterConfig;
    }
}
