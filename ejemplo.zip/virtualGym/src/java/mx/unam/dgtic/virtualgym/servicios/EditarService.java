/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servicios;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.unam.dgtic.modelo.dao.UserJDBC;
import mx.unam.dgtic.modelo.dto.User;

/**
 *
 * @author Alejandro
 */
public class EditarService {
    private UserJDBC userJDBC;
    private User datos;
    
    public EditarService(){
        userJDBC = new UserJDBC();
        datos = new User();
    }
    
    public void cargaInfoUser(int id){
        try {
            datos = userJDBC.selectData(id);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void actualizaUsuario(User us){
        try {
            userJDBC.updateData(us);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public User getDatos() {
        return datos;
    }

    public void setDatos(User datos) {
        this.datos = datos;
    }
    
}
