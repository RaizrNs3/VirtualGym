/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.dgtic.virtualgym.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.unam.dgtic.modelo.dto.User;
import mx.unam.dgtic.virtualgym.servicios.RegistroService;

/**
 *
 * @author Alejandro
 */
public class RegistroServlet extends HttpServlet {
    
    private static String PANTALLA_NUEVO = "/controller?action=nuevo";
    private static String PANTALLA_INICIO = "/controller?action=iniciojsp";
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        RegistroService registro = new RegistroService();
        User nuevoUser = new User();
        int index = 0;
        List<String> parametros = new ArrayList<>();
        
        parametros.add(request.getParameter("username"));
        parametros.add(request.getParameter("password"));
        parametros.add(request.getParameter("mail"));
        parametros.add(request.getParameter("gender"));
        parametros.add(request.getParameter("age"));
        parametros.add(request.getParameter("height"));
        parametros.add(request.getParameter("weight"));
        
        if (parametros.get(0).length()<60) {
            nuevoUser.setUserName(parametros.get(0));
            index++;
        }
        
        if (parametros.get(1).length()>=8) {
            nuevoUser.setPassword(parametros.get(1));
            index++;
        }
        
        if (parametros.get(2).contains("@")) {
            nuevoUser.setEmail(parametros.get(2));
            index++;
        }
       
        if (parametros.get(3).equals("M")||parametros.get(3).equals("F")) {
            nuevoUser.setSex(parametros.get(3).charAt(0));
            index++;
        }
        
        if (Integer.parseInt(parametros.get(4))>10 && Integer.parseInt(parametros.get(4))< 80) {
            nuevoUser.setAge(Integer.parseInt(parametros.get(4)));
            index++;
        }
      
        if (Double.parseDouble(parametros.get(5))>0) {
            nuevoUser.setHeight(Double.parseDouble(parametros.get(5)));
            index++;
        }
        
        if (Double.parseDouble(parametros.get(6))>0) {
            nuevoUser.setWeight(Double.parseDouble(parametros.get(6)));
            index++;
        }
        
        if (index == 7) {
            nuevoUser.setImc();
            registro.registraUsuario(nuevoUser);
            request.getRequestDispatcher(PANTALLA_INICIO).forward(request, response);
        }else{
               request.getRequestDispatcher(PANTALLA_NUEVO).forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
